/**
 * 
 */

function validaCampos(){
	
	if(document.formulario.txtCPF.value == ''){
		alert('Digite o CPF');
		return;
	}
	if(document.formulario.txtNome.value == ''){
		alert('Digite o nome!');
		return;
	}
	if(document.formulario.txtSalarioBruto.value == ''){
		alert('Digite o salario!');
		return;
	}
	if(document.formulario.txtDesconto.value == ''){
		alert('Digite o desconto!')
		return;
	}
	
	document.getElementById("operacao").value = 'Calcular';
	
	formulario.submit();
}

function mascaraCpf(valor){
	return valor.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/g, "\$1.\$2.\$3\-\$4.");
	
}
function formatarCpf(campoTexto){
	campoTexto.value = mascaraCpf(campoTexto.value);
}

function apenasNumericos(oEvent){
	var tecla;
	var IE = navigator.userAgent.index0f('MSIE') > 1;
	if (IE){
		tecla = oEvent.keyCode;
	}else {
		tecla = oEvent.charCode;
		
	}
	if(((tecla > 47) && (tecla < 58)) || (tecla == 8) || (tecla == 0) || (tecla == 46) ){
		return true;
	}
	return false;
}














