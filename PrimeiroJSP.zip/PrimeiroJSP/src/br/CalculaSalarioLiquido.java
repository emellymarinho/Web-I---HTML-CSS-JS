package br;

public class CalculaSalarioLiquido {
	public double calculaSalario(double salarioBruto, double desconto) {
		double resultado;
		resultado = salarioBruto - (salarioBruto * (desconto / 100));
		return resultado;
	
	}

}

