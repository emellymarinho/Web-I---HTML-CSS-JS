package br;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Banco {
	private static String status = "Nao consegui conectar";

	public static Connection obterConexao() throws ClassNotFoundException, SQLException {
		try {
			Connection conexao = null;
			String driver = "com.mysql.cj.jdbc.Driver";
			Class.forName(driver);

			String url = "jdbc:mysql://localhost/cadastro?useSSL=true";
			String user = "root";
			String senha = "kkk1";
			conexao = DriverManager.getConnection(url, user, senha);

			if (conexao != null) {
				status = "Conectou!";
			}

			return conexao;

		} catch (Exception e) {
			System.out.println("Nao conectou" + e.getMessage());
			return null;

		}
	}

	public static String RetornaConnexao() {
		return status;
	}

	public static boolean FechaConexao() throws ClassNotFoundException, SQLException {
		try {
			Banco.obterConexao().close();
			return true;
		} catch (Exception e) {
			return false;
		}

	}

}
