package br;

public class Epessoa {
	private String cpf;
	private String nome;
	private double salario;
	private double desconto;
	private double salarioLiq;
	
	/**
	 * @param cpf
	 * @param nome
	 * @param salario
	 * @param desconto
	 * @param salarioLiq
	 */
	public Epessoa(String cpf, String nome, double salario, double desconto, double salarioLiq) {
		this.cpf = cpf;
		this.nome = nome;
		this.salario = salario;
		this.desconto = desconto;
		this.salarioLiq = salarioLiq;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public double getDesconto() {
		return desconto;
	}
	public void setDesconto(double desconto) {
		this.desconto = desconto;
	}
	public double getSalarioLiq() {
		return salarioLiq;
	}
	public void setSalarioLiq(double salarioLiq) {
		this.salarioLiq = salarioLiq;
	}
	
	
	
	

}
